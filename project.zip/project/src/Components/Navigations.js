import { Outlet, NavLink } from "react-router-dom";
import React from 'react'
import '../cssFolder/Navigations.css'
import '../cssFolder/Main.css'
import './LoginForm'

export default function Navigations({ Logout }) {
  
  return (
    <div>
      <header>Welcome {localStorage.getItem('username')}</header>
      <nav className='Navigation'>
        <NavLink to="/">Home</NavLink>|
        <NavLink to="/About">About</NavLink>|
        <NavLink to="/Orders">Orders</NavLink>|
        <NavLink to="/Cart">Cart</NavLink>|
       <button onClick={Logout}>logout</button>
          
      </nav>


      <Outlet />
    </div>
  )
};