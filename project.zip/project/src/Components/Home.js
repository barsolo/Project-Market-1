import React from 'react';//i really dont know why this doesnt work without this
import Items from "../Items.json";
import "../cssFolder/Home.css";



export default function Home({onAdd}) {
  return (
    <main >
      <header >Home:</header>
      <div className='itemDisplay'>
        {Items && Items.map((item) => 
          {return (
            <div key={item.id} className='itemContainer'>
              <img src={item.icon} alt={item.alt} height={200} width={200} />
              <div>
                <div>Product name: {item.itemName}</div>
                <div>Product description: {item.description}</div>
                <div>Amount in storage: {item.qty}</div>
                <div>Product price: {item.price}₪</div>
                <br></br>
                <button onClick={()=> onAdd(item)} >Add to cart</button >
              </div>
            </div>
          )}
        )}
      </div>
    </main>
  );
};