import React from 'react'

export default function About() {
    return (
      <main >
        <header >About</header>
        <p>About</p>
        
      </main>
    );
  };