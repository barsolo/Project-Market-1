import React from 'react';
import "../cssFolder/Home.css";
import "../cssFolder/Cart.css";

export default function Cart(props) {
    const { onAdd, onRemove, cartItems, implementOrder } = props;
    const itemsPrice = cartItems.reduce((a, c) => a + c.qty * c.price, 0);
    const totalPrice = itemsPrice;
    
    return (
        <main>
            <h2>Cart Items</h2>
            <div>
                {cartItems.length === 0 && <div>Cart is empty</div>}
                {cartItems.map((item) => (
                    <div key={item.id} className="row">
                        <div >{item.itemName}</div>
                        <div >
                            <button onClick={() => onRemove(item)} className="remove">
                                -
                            </button>{' '}
                            <button onClick={() => onAdd(item)} className="add">
                                +
                            </button>
                        </div>

                        <div>
                            {item.qty} x ₪{item.price.toFixed(2)}
                        </div>
                    </div>
                ))}

                {cartItems.length !== 0 && (
                    <>
                        <hr />
                        <div >
                            <div >
                                <strong>Total Price</strong>
                            </div>
                            <div >
                                <strong>₪{totalPrice.toFixed(2)}</strong>
                            </div>
                        </div>
                        <hr />
                        <div className="row">
                            <button onClick={()=> alert("could not implement this function")}>
                                Checkout
                            </button>
                        </div>
                    </>
                )}
            </div>
        </main>
    );
}