import React from 'react'
import LoginForm from './LoginForm';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navigations from "./Navigations";
import Home from "./Home";
import Orders from "./Orders";
import About from "./About";
import NoPage from "./NoPage";
import Users from '../Users.json';
import '../cssFolder/Main.css'
import Cart from './Cart';



function RenderThis(props) {

    const [user, setUser] = React.useState({ name: "" });
    const [error, setError] = React.useState("");
    let [cartItems, setCartItems] = React.useState([]);

    if (localStorage.getItem('username') != "" && localStorage.getItem('email') != "" && user.name == "") {
        setUser({ name: localStorage.getItem('username') });
    }
    //////
    const onAdd = (product) => {
        const exist = cartItems.find((x) => x.id === product.id);
        if (exist) {
            setCartItems(
                cartItems.map((x) =>
                    x.id === product.id ? { ...exist, qty: exist.qty + 1 } : x
                )
            );
        } else {
            setCartItems([...cartItems, { ...product, qty: 1 }]);
        }
    };
///////
    const onRemove = (product) => {
        const exist = cartItems.find((x) => x.id === product.id);
        if (exist.qty === 1) {
            setCartItems(cartItems.filter((x) => x.id !== product.id));
        } else {
            setCartItems(
                cartItems.map((x) =>
                    x.id === product.id ? { ...exist, qty: exist.qty - 1 } : x
                )
            );
        }
    };
    ////////
    const implementOrder = (cartItems, totalPrice) => {
        
    }

    //////
    const Login = Details => {
        setError({ email: "", name: "", password: "" });
        let userList = Users.users;
        if (Details.email != "" && Details.name != "" && Details.password != "") {

            for (let i = 0; i < userList.length; i++) {
                if (userList[i].Email == Details.email) {
                    if (userList[i].Password != Details.password || userList[i].Name != Details.name) {
                        setError("detail do not match");
                        break;
                    }
                    else {
                        localStorage.setItem('email', userList[i].Email);
                        localStorage.setItem('username', userList[i].Name);
                        setUser({ name: localStorage.getItem('username') });
                        localStorage.setItem('orders', JSON.stringify(userList[i].Orders));
                        localStorage.setItem('access', userList[i].Access);
                        break;
                    }
                }
                if (i == userList.length - 1) {
                    setError("incorrect email");
                }
            }

        }
        else {
            setError("you need to input all the info");
        }

    }
    const Logout = () => {
          localStorage.setItem('email', "");
          localStorage.setItem('username', "");
          setUser({ name: "" });
          localStorage.setItem('orders', "");
          localStorage.setItem('access', "");
        
    }


    if (localStorage.getItem('email') == "")
        return (
            <div className='loginPage'>
                <LoginForm Login={Login} Error={error} />
            </div>
        )

    else {
        return (
            <BrowserRouter>
                <Navigations Logout={Logout} />
                <Routes>
                    <Route path="/" index element={<Home onAdd={onAdd} />} />
                    <Route path="Orders" element={<Orders />} />
                    <Route path="Cart" element={<Cart onAdd={onAdd} onRemove={onRemove} cartItems={cartItems} implementOrder={implementOrder} />} />
                    <Route path="About" element={<About />} />
                    <Route path="*" element={<NoPage />} />
                </Routes>
            </BrowserRouter>
        );
    }
}
export default RenderThis;