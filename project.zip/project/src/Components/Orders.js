import React from 'react'
import '../cssFolder/Orders.css'
import '../cssFolder/Main.css'


export default function Orders() {
  let orderInfo = JSON.parse(localStorage.getItem('orders'));
  console.log(orderInfo);
  
  return (
    <main  >
      <div>
        <header >Your Orders</header>
        <div className='List Vertical'>
          {orderInfo && orderInfo.map((order) => <DisplayOrders key={order.id}  order = {order.Order} totalPrice={order.totalPrice} />)}
        </div>
      </div>
    </main>
  );
};
function DisplayOrders({order,totalPrice}) {
  if (order === undefined) {
    return <div>you do not have any orders</div>
  }
  else return (
    <div className='ItemList'>
      {order && order.map((order) => 
        {return (
          <div key={order.id}>{order.itemName} x {order.qty},</div>
        )
      })}
      total Price:  {totalPrice}
    </div>
  )
}