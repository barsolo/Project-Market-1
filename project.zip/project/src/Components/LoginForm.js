import React from 'react'
import '../cssFolder/LoginForm.css';

function LoginForm({ Login , Error}) {
  const [Details, setDetails] = React.useState({ email: "", name: "", password: "" });
 // console.log(Error);
  

  const submitHandler = e => {
    e.preventDefault();
      Login(Details);
  }

  return (
    <div>
      <form onSubmit={submitHandler}>
        <div className='form-inner'>
          <h2 className='logText'>Login</h2>
          <div>{Error}</div>
          <div className='form-group'></div>
          <div className='form-group'>
            <label htmlFor="email">Email: </label>
            <input type='email' name='email' id='email' onChange={e => setDetails({ ...Details, email: e.target.value })} value={Details.email} />
          </div>
          <div className='form-group'>
            <label htmlFor="name">name: </label>
            <input type='name' name='name' id='name' onChange={e => setDetails({ ...Details, name: e.target.value })} value={Details.name} />
          </div>
          <div className='form-group'>
            <label htmlFor="password">Password: </label>
            <input type='password' name='password' id='password' onChange={e => setDetails({ ...Details, password: e.target.value })} value={Details.password} />
          </div>
          <button type='submit' value='LOGIN' className='form-button'>Login</button>
        </div>
      </form>
    </div>
  )
}
function Print(props) {
  return <div className="errorList">{props.error}</div>;
}

export default LoginForm;