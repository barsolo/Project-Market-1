import './cssFolder/App.css';
import React from 'react';
import './Users.json';
import RenderThis from './Components/RenderThis';

function App(props) {

  return (
    <div className='site-layout'>
      <header className='header-design'> market</header>
      <div >
        <RenderThis />
      </div>
      <div>legal stuff here</div>
    </div>
  );
}

export default App;